﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SatyaWebGridCustomPagingLinks.Models; 

namespace SatyaWebGridCustomPagingLinks.Connection
{
    public class Connection
    {
        public DataSet mydata()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Mycon"].ToString());
            SqlCommand cmd = new SqlCommand("Sp_StudentDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet myrec = new DataSet();
            da.Fill(myrec);
            return myrec;
        }

    }  
}