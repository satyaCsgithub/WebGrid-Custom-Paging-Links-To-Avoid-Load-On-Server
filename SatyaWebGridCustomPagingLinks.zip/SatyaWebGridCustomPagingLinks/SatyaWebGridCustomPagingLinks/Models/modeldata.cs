﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SatyaWebGridCustomPagingLinks.Models
{
    public class modeldata
    {
        public Int64 SM_StudentID { get; set; }
        public string SM_Name { get; set; }
    }
}