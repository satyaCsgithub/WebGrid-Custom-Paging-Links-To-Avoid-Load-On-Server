﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using SatyaWebGridCustomPagingLinks.Models;
using System.Web.Helpers;

namespace SatyaWebGridCustomPagingLinks.Controllers
{
    public class GridviewController : Controller
    {
        //
        // GET: /Gridview/
        
        public ActionResult Index(int? page)
        {
            List<modeldata> lmd = new List<modeldata>();
            //creating list of model.  

            DataSet ds = new DataSet();

            Connection.Connection con = new Connection.Connection();

            //The connection namespace as we mentioned earlier .  
            //namespace Gridsample.Connection.  

            // connection to getdata.  

            ds = con.mydata();

            // fill dataset  


            foreach (DataRow dr in ds.Tables[0].Rows)

            // loop for adding add from dataset to list<modeldata>  
            {
                lmd.Add(new modeldata
                {
                    // adding data from dataset row in to list<modeldata>  
                    SM_StudentID = Convert.ToInt64(dr["SM_StudentID"]),
                    SM_Name = dr["SM_Name"].ToString()
                });
            }
            return View(lmd.ToList());
        }

        public ActionResult EfficientWay()
        {
            return View();
        }

        [HttpGet]
        public JsonResult EfficientPaging(int? page)
        {
            List<modeldata> lmd = new List<modeldata>();
            //creating list of model.  

            DataSet ds = new DataSet();

            Connection.Connection con = new Connection.Connection();

            //The connection namespace as we mentioned earlier .  
            //namespace Gridsample.Connection.  

            // connection to getdata.  

            ds = con.mydata();

            // fill dataset  


            foreach (DataRow dr in ds.Tables[0].Rows)

            // loop for adding add from dataset to list<modeldata>  
            {
                lmd.Add(new modeldata
                {
                    // adding data from dataset row in to list<modeldata>  
                    SM_StudentID = Convert.ToInt64(dr["SM_StudentID"]),
                    SM_Name = dr["SM_Name"].ToString()
                });
            }
            int skip = page.HasValue ? page.Value - 1 : 0;
            var data = lmd.OrderBy(o => o.SM_StudentID).Skip(skip * 5).Take(5).ToList();
            var grid = new WebGrid(data);
            var htmlString = grid.GetHtml(tableStyle: "webGrid",
                                          headerStyle: "header",
                                          alternatingRowStyle: "alt",
                                          htmlAttributes: new { id = "DataTable" });
            return Json(new
            {
                Data = htmlString.ToHtmlString(),
                Count = lmd.Count() / 5
            }, JsonRequestBehavior.AllowGet);
        }
    }
}
    
